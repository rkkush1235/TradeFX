"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { cn } from "@/utils/format";
import { useAppStore } from "@/store/useAppStore";
import { useAuth } from "@/hooks/useAuth";
import {
  BarChart3,
  LayoutDashboard,
  Shield,
  User,
  Users,
  Wallet,
  Landmark,
  HandCoins,
  type LucideIcon,
} from "lucide-react";

const userLinks = [
  {
    href: "/dashboard",
    label: "Dashboard",
    icon: LayoutDashboard,
  },
  {
    href: "/markets",
    label: "Markets",
    icon: BarChart3,
  },
  {
    href: "/trades",
    label: "Position",
    icon: BarChart3,
  },
  {
    href: "/wallet",
    label: "Wallet",
    icon: Wallet,
  },
  {
    href: "/deposit",
    label: "Deposit",
    icon: Landmark,
  },
  {
    href: "/withdraw",
    label: "Withdraw",
    icon: HandCoins,
  },
  {
    href: "/profile",
    label: "Profile",
    icon: User,
  },
];

const adminLinks = [
  {
    href: "/admin",
    label: "Dashboard",
    icon: LayoutDashboard,
  },
  {
    href: "/admin/users",
    label: "Users",
    icon: User,
  },
  {
    href: "/admin/kyc",
    label: "KYC",
    icon: Shield,
  },
  {
    href: "/admin/deposits",
    label: "Deposits",
    icon: Landmark,
  },
  {
    href: "/admin/withdrawals",
    label: "Withdrawals",
    icon: HandCoins,
  },
  {
    href: "/admin/bank-accounts",
    label: "Deposit Accounts",
    icon: Landmark,
  },
];

const superAdminLinks = [
  {
    href: "/super-admin",
    label: "Dashboard",
    icon: LayoutDashboard,
  },
  {
    href: "/super-admin/admins",
    label: "Admins",
    icon: Shield,
  },
  {
    href: "/super-admin/users",
    label: "Users",
    icon: Users,
  },
  {
    href: "/super-admin/bank-accounts",
    label: "Deposit Accounts",
    icon: Landmark,
  },
];

function normalizeRole(
  role: unknown,
): "user" | "admin" | "super_admin" {
  const normalized = String(role ?? "")
    .trim()
    .toLowerCase();

  if (normalized === "super_admin") {
    return "super_admin";
  }

  if (normalized === "admin") {
    return "admin";
  }

  return "user";
}

export function Sidebar() {
  const pathname = usePathname();

  const {
    sidebarOpen,
    setSidebarOpen,
  } = useAppStore();

  const { appUser, loading } = useAuth();

  const role = normalizeRole(
    appUser?.role,
  );

  /**
   * IMPORTANT:
   *
   * Never default to user navigation while
   * authentication is still loading.
   *
   * This prevents:
   *
   * super_admin
   *      ↓
   * user sidebar
   *      ↓
   * super_admin sidebar
   *
   * flashing during authentication.
   */
  if (loading) {
    return null;
  }

  const navLinks =
    role === "super_admin"
      ? superAdminLinks
      : role === "admin"
        ? adminLinks
        : userLinks;

  const bottomLinks =
    role === "super_admin"
      ? superAdminLinks
      : role === "admin"
        ? adminLinks
        : userLinks.filter((item) =>
            [
              "/dashboard",
              "/markets",
              "/trades",
              "/wallet",
              "/profile",
            ].includes(item.href),
          );

  console.log("[Sidebar] rendering:", {
    uid: appUser?.uid,
    role,
    pathname,
    links: navLinks.map(
      (item) => item.href,
    ),
  });

  return (
    <>
      {/* Desktop sidebar */}
      <aside className="glass fixed left-4 top-4 z-40 hidden h-[calc(100vh-2rem)] w-64 p-4 md:block">
        <SidebarContent
          pathname={pathname}
          links={navLinks}
        />
      </aside>

      {/* Mobile overlay */}
      {sidebarOpen && (
        <button
          type="button"
          aria-label="Close sidebar"
          className="fixed inset-0 z-40 bg-black/50 md:hidden"
          onClick={() =>
            setSidebarOpen(false)
          }
        />
      )}

      {/* Mobile sidebar */}
      <aside
        className={cn(
          "glass fixed left-0 top-0 z-50 h-screen w-72 p-4 transition-transform md:hidden",
          sidebarOpen
            ? "translate-x-0"
            : "-translate-x-full",
        )}
      >
        <SidebarContent
          pathname={pathname}
          links={navLinks}
          onNavigate={() =>
            setSidebarOpen(false)
          }
        />
      </aside>

      {/* Mobile bottom navigation */}
      <nav className="fixed inset-x-3 bottom-3 z-40 grid grid-cols-5 rounded-2xl border border-zinc-700/80 bg-zinc-950/95 p-1 shadow-2xl backdrop-blur md:hidden">
        {bottomLinks
          .slice(0, 5)
          .map((item) => {
            const Icon = item.icon;

            const active =
              pathname === item.href ||
              pathname.startsWith(
                `${item.href}/`,
              );

            return (
              <Link
                key={item.href}
                href={item.href}
                className={cn(
                  "flex min-h-14 flex-col items-center justify-center gap-1 rounded-xl px-1 text-[10px] font-medium transition",
                  active
                    ? "bg-emerald-500/20 text-emerald-300"
                    : "text-zinc-400",
                )}
              >
                <Icon size={18} />

                <span className="max-w-full truncate">
                  {item.label}
                </span>
              </Link>
            );
          })}
      </nav>
    </>
  );
}

function SidebarContent({
  pathname,
  links,
  onNavigate,
}: {
  pathname: string;
  links: Array<{
    href: string;
    label: string;
    icon: LucideIcon;
  }>;
  onNavigate?: () => void;
}) {
  return (
    <div className="flex h-full flex-col">
      <div>
        <p className="text-xs uppercase tracking-[0.25em] text-zinc-400">
          Trade FX
        </p>

        <h2 className="mt-2 text-xl font-semibold">
          Live Markets
        </h2>
      </div>

      <nav className="mt-8 space-y-2">
        {links.map((item) => {
          const Icon = item.icon;

          const active =
            pathname === item.href ||
            pathname.startsWith(
              `${item.href}/`,
            );

          return (
            <Link
              key={item.href}
              href={item.href}
              onClick={onNavigate}
              className={cn(
                "flex items-center gap-3 rounded-xl px-3 py-2 text-sm transition",
                active
                  ? "bg-emerald-500/20 text-emerald-300"
                  : "text-zinc-300 hover:bg-zinc-800/70",
              )}
            >
              <Icon size={16} />

              {item.label}
            </Link>
          );
        })}
      </nav>

      <div className="mt-auto" />
    </div>
  );
}