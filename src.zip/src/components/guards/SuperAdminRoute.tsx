"use client";

import { useAuth } from "@/hooks/useAuth";
import { BrandLoader } from "@/components/common/BrandLoader";
import { useRouter } from "next/navigation";
import { useEffect } from "react";

export function SuperAdminRoute({
  children,
}: {
  children: React.ReactNode;
}) {
  const { appUser, loading } = useAuth();
  const router = useRouter();

  const isSuperAdmin = appUser?.role === "super_admin";

  useEffect(() => {
    if (loading || !appUser) return;

    if (appUser.role !== "super_admin") {
      if (appUser.role === "admin") {
        router.replace("/admin");
      } else {
        router.replace("/dashboard");
      }
    }
  }, [loading, appUser, router]);

  if (loading || !appUser || !isSuperAdmin) {
    return <BrandLoader />;
  }

  return <>{children}</>;
}