"use client";

import { useAuth } from "@/hooks/useAuth";
import { BrandLoader } from "@/components/common/BrandLoader";
import { useRouter } from "next/navigation";
import { useEffect } from "react";

export function AdminRoute({
  children,
}: {
  children: React.ReactNode;
}) {
  const { appUser, loading } = useAuth();
  const router = useRouter();

  const isAdmin = appUser?.role === "admin";

  useEffect(() => {
    if (loading || !appUser) return;

    if (appUser.role === "super_admin") {
      router.replace("/super-admin");
      return;
    }

    if (appUser.role !== "admin") {
      router.replace("/dashboard");
    }
  }, [loading, appUser, router]);

  if (loading || !appUser) {
    return <BrandLoader />;
  }

  if (appUser.role !== "admin") {
    return <BrandLoader />;
  }

  return <>{children}</>;
}